Open index.html in your browser (double-click) to view the site. This is a static offline demo — orders are saved to your browser localStorage.
Contact email used: resource.ecocraft@gmail.com
Phone used: +91 98765 43210
